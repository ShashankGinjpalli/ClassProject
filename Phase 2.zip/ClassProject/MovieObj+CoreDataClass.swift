//
//  MovieObj+CoreDataClass.swift
//  ClassProject
//
//  Created by Shashank Ginjpalli on 11/21/19.
//  Copyright © 2019 Shashank Ginjpalli. All rights reserved.
//
//

import Foundation
import CoreData

@objc(MovieObj)
public class MovieObj: NSManagedObject {

}
