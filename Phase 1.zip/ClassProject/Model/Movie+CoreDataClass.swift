//
//  Movie+CoreDataClass.swift
//  ClassProject
//
//  Created by Shashank Ginjpalli on 11/4/19.
//  Copyright © 2019 Shashank Ginjpalli. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Movie)
public class Movie: NSManagedObject {

}
